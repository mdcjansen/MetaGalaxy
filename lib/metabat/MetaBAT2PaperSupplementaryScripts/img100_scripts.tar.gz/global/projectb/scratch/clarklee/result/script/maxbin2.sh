#!/bin/bash -l

#SBATCH -N 1         #Use 2 nodes
#SBATCH -t 00:30:00  #Set 30 minute time limit

###module load bowtie2/2.2.3 
module load hmmer/3.1b2
###module load idba/1.1.1

srun perl run_MaxBin.pl -contig ../dataset/CAMI_low_RL_S001__insert_270_GoldStandardAssembly.fasta -abund ../dataset/depth-only-low.txt -out binlow -thread 16
##--help 
##

