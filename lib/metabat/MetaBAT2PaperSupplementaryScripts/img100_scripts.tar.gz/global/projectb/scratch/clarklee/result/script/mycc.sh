#!/bin/bash
#SBATCH --image=docker:990210oliver/mycc.docker:v1
#SBATCH -N 1
#SBATCH -t 09:29:00

srun shifter MyCC.py contigs.fna -a coverage.tsv 
