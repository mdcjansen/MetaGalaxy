#!/bin/bash

module load hmmer/3.1b2
module load pplacer    
module load subread/1.5.0p2

../utils/transform-coverage-profile -c coverage.tsv -t log
../bin/Binsanity -f . -l contigs.fna -p -10 -c coverage.tsv.lognorm
