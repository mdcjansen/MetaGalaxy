#!/bin/bash
#SBATCH -N 1
#SBATCH -t 23:59:00

source activate coenv

#cat coverage.tsv | cut -f1 > list
#filter out ambiguity char if needed

python ../../CONCOCT-0.4.0/scripts/fasta_to_features.py contigs.fna 157400 4 kmer_4_tmp.csv
cp coverage.tsv coverage.tsv1
sed -i '1s/^/contigs\tsample\n/' coverage.tsv1

srun python cocacola.py --contig_file contigs.fna --abundance_profiles coverage.tsv1 --composition_profiles high/kmer_4_tmp.csv --output result.csv

