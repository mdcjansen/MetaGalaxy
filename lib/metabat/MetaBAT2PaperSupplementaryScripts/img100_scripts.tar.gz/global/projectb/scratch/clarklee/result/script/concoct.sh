#!/bin/bash
#SBATCH --image=docker:binpro/concoct_latest:latest
#SBATCH -N 1
#SBATCH -t 02:30:00
#SBATCH --mem=233G

srun shifter concoct --coverage_file dataset/depth-only-high.txt  --composition_file dataset/CAMI_high_GoldStandardAssembly.fasta -b concoct_res/

